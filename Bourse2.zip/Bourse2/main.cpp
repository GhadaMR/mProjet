#include <iostream>
#include <string>
#include<vector>
#include<fstream>
#include <ctime>
#include <cmath>
#include <cstdlib>
#include <sstream>
#include<chrono>
#include<map>
#include <cassert>
#include "trader.h"
#include "bourse.h"
#include "portefeuille.h"
#include"date.h"
#include"test.h"
#include"prixjournaliers.h"
#include"simulation.h"
#include"titre.h"
using namespace std;

void Date::operator=(const Date& d){
    jour=d.jour;
    mois=d.mois;
    annee=d.annee;
}
bool Date::operator==(const Date& d)const{
   return (jour==d.jour &&mois==d.mois && annee==d.annee);
   }
bool Date::operator< (const Date& d)const{
   return (d.annee<annee || (d.annee==annee && d.mois<mois) || (d.annee==annee && d.mois==mois && d.jour<jour));
}
void Date:: incrementerDate()
   {

        int limiteJour = 31;
        if (mois == 2) {
                if (annee % 4 == 0) {
                    limiteJour = 29;
                } else {
                    limiteJour = 28;
                    }
      } else if (mois == 4 || mois == 6 || mois == 9 || mois == 11) {
               limiteJour = 30;
     }
    jour++;
    if (jour > limiteJour) {
        jour = 1;
        mois++;
    }
    if (mois > 12) {
        jour=1;
        mois = 1;
        annee++;
    }

}
Date::Date(int j,int m,int a):jour(j), mois(m),annee(a){}


class PersistancePrixJournaliers {
public:
    static vector<PrixJournalier> lirePrixJournaliersDUnFichier(string chemin) {
        vector<PrixJournalier> historique;
        ifstream f(chemin);
        int nbLignes = 0;
        string entete;
        if (f.is_open()) {
            getline(f, entete);
            while (!f.eof()) {
                PrixJournalier pj;
                f >> pj;
                historique.push_back(pj);
                nbLignes++;
            }
        }
        f.close();
        return historique;
    }
};
vector<PrixJournalier>BourseVector:: getPrixjournaliers(){
        return prixj;
    }
vector<string>BourseVector:: getActionsDisponiblesParPrix(double prix)
        {
        vector<PrixJournalier> prj =getPrixJournaliersParPrix(prix);
        vector<string> actionsParPrix;
        for(auto i : prj)
        {
                actionsParPrix.push_back(i.getAction());
        }
        return actionsParPrix;

}
vector<string>BourseVector:: getActionsDisponiblesParAujourdhui()
    {
        vector<PrixJournalier> prjr=getPrixJournaliersDisponiblesParAujourdhui();
        vector<string> actionsAujourdhui;
        for(auto i : prjr){
                actionsAujourdhui.push_back(i.getAction());
                  }
        return actionsAujourdhui;
    }
vector<string> BourseVector::getActionsDisponiblesParDate(Date date)
    {
        vector<PrixJournalier> prj =getPrixJournaliersParDate(date);
        vector<string> actions;
        int i=0;

        for (auto i : prj)
        {
                actions.push_back(i.getAction());
            }
        return actions;

}
vector<PrixJournalier> BourseVector::getPrixJournaliersParDate(Date date)
    {
        vector<PrixJournalier> prix_journaliers;
        int i=0;
        if(!prixj.empty()&& date < dateAujourdhui){
         while ( prixj.size()>i)
        {
            if (prixj[i].getDate() == date)
            {
                prix_journaliers.push_back(prixj[i]);
            }
             i++;
        }
        return prix_journaliers;
    }
    }
vector<PrixJournalier>BourseVector:: getPrixJournaliersParAction(string action){
       vector<PrixJournalier> prix_journaliers;
        int i=0;
        if(!prixj.empty()){
        while (prixj[i].getDate() < dateAujourdhui && prixj.size()>i)
        {

            if (prixj[i].getAction()==action)
            {
                prix_journaliers.push_back(prixj[i]);
            }
             i++;
        }
        return prix_journaliers;
    }
    }
vector<PrixJournalier> BourseVector:: getPrixJournaliersParPrix(double prix){
        vector<PrixJournalier> prix_journaliers;
        int i=0;
        if(!prixj.empty()){
           while (prixj[i].getDate() < dateAujourdhui && prixj.size()>i)
          {
              if (prixj[i].getPrix() <=prix)
              {
                prix_journaliers.push_back(prixj[i]);
              }
              i++;
          }
        return prix_journaliers;
    }
}
vector<PrixJournalier> BourseVector:: getPrixJournaliersParPrixAujourdhui(double prix){
        vector<PrixJournalier> prix_journaliers;
        int i=0;
        if(!prixj.empty()){
           while (prixj[i].getDate()== dateAujourdhui && prixj.size()>i)
          {
              if (prixj[i].getPrix() <=prix)
              {
                prix_journaliers.push_back(prixj[i]);
              }
              i++;
          }
        return prix_journaliers;
    }
   }
vector<PrixJournalier> BourseVector::getPrixJournaliersDisponiblesParAujourdhui(){
        vector<PrixJournalier> prix_journaliers;
        int i=0;
        if(!prixj.empty()){
         while ( prixj.size()>i)
        {
            if (prixj[i].getDate() == dateAujourdhui)
            {
                prix_journaliers.push_back(prixj[i]);
            }
             i++;
        }
        return prix_journaliers;
    }
    }
void Portefeuille::ajouterTitre(Titre titre){
for ( auto t : titres) {
        if (t.getAction() == titre.getAction())
            t.setQt(titre.getQt());
        else
         titres.push_back(titre);}
}
void Portefeuille::retirerTitre(Titre* titre) {
    for (auto it = titres.begin(); it != titres.end(); ++it) {
        if (it->getAction() == titre->getAction() && it->getQt() == titre->getQt()) {
            titres.erase(it);
            break;
    }
}
}
void Portefeuille::deposerMontant(double montant){

    solde+=montant;
}
void Portefeuille::retirerMontant(double montant){
    solde-=montant;
}

Transaction Trader::choisirTransaction( Bourse& bourse,   Portefeuille &portefeuille){
    TraderAleatoire trader (portefeuille);
    vector<PrixJournalier> prixJournaliersDisponiblesDansLaBourseAujourdhui=bourse.getPrixJournaliersDisponiblesParAujourdhui();
    vector<Titre> titresDeTrader=portefeuille.getTitres();
    vector<PrixJournalier> titresDeTraderDisponiblesDansLaBourseAujourdhui;
    vector<PrixJournalier> prixJournaliersDisponiblesaAcheter =bourse.getPrixJournaliersParPrix(portefeuille.getSolde());
    for(auto i :prixJournaliersDisponiblesDansLaBourseAujourdhui){
        for (auto j:titresDeTrader){
            if(i.getAction()==j.getAction()){
                titresDeTraderDisponiblesDansLaBourseAujourdhui.push_back(i);
            }
        }
    }
    double quantiteAvendre;
    if (titresDeTrader.empty()){ //portefeuille vide
        if(prixJournaliersDisponiblesaAcheter.empty()){//bourse vide benesba lel trader
            Transaction transaction(rienfaire);
            return transaction;
        }
        else{ //achat des titres
           int index = rand() % prixJournaliersDisponiblesaAcheter.size();
           PrixJournalier pj= prixJournaliersDisponiblesaAcheter[index];
           double prixAction= pj.getPrix();
           string action =pj.getAction();
           double quantite= floor(portefeuille.getSolde()/prixAction);
           Transaction transaction(acheter,action,quantite);
           Titre t(action, quantite);
           trader.getPortefeuille().ajouterTitre(t);
           trader.getPortefeuille().retirerMontant(prixAction*quantite);
           return transaction;
        }
    }

    else{ //portefeuille !=vide
            if(portefeuille.getSolde()==0){ //trader ma3endouch solde
                 if(titresDeTraderDisponiblesDansLaBourseAujourdhui.empty()){ //maynjmch ybi3 les titres mta3ah khater mach mawjoudin
                     Transaction transaction(rienfaire);
                     return transaction;
                 }
                 else{ //ybi3 les titres mt3h

                    int index = rand() % titresDeTraderDisponiblesDansLaBourseAujourdhui.size();
                    PrixJournalier prixJournalierAvendre=titresDeTraderDisponiblesDansLaBourseAujourdhui[index];
                    for(Titre i: titresDeTrader){
                          if (i.getAction()== prixJournalierAvendre.getAction()){
                             quantiteAvendre = 1.0 + static_cast<double>(rand()) / RAND_MAX * (i.getQt());
                             break;}
                    }
                    string action =prixJournalierAvendre.getAction();
                    double prixAction = prixJournalierAvendre.getPrix();
                    Titre titreAvendre(action,quantiteAvendre);
                    trader.getPortefeuille().retirerTitre(&titreAvendre);
                    trader.getPortefeuille().deposerMontant(prixAction*quantiteAvendre);
                    Transaction transaction(vendre,action,quantiteAvendre);
                    return transaction;
                 }
            }
            else{ //trader 3enda solde  w protefeuille mch vide:aleatoire

                TypeTransaction type = static_cast<TypeTransaction>(rand()%3);
                if(type==acheter){ //achat
                    if(prixJournaliersDisponiblesaAcheter.empty()){ //mfmch articles fil bourse lyowm a9al mil prix mt3h
                        do{
                          TypeTransaction type = static_cast<TypeTransaction>(rand()%3);}while(type=acheter);
                        if (type==vendre){
                            if(titresDeTraderDisponiblesDansLaBourseAujourdhui.empty()){
                                Transaction transaction(rienfaire);
                                return transaction;}

                            int index = rand() % titresDeTraderDisponiblesDansLaBourseAujourdhui.size();
                            PrixJournalier prixJournalierAvendre=titresDeTraderDisponiblesDansLaBourseAujourdhui[index];
                            for(Titre i: titresDeTrader){
                                if (i.getAction()== prixJournalierAvendre.getAction()){
                                  double quantiteAvendre = 1.0 + static_cast<double>(rand()) / RAND_MAX * (i.getQt());
                                  break;}
                            }
                            string action =prixJournalierAvendre.getAction();
                            double prixAction = prixJournalierAvendre.getPrix();
                            Titre titreAvendre(action,quantiteAvendre);
                            trader.getPortefeuille().retirerTitre(&titreAvendre);
                            trader.getPortefeuille().deposerMontant(prixAction*quantiteAvendre);
                            Transaction transaction(vendre,action,quantiteAvendre);
                            return transaction;
                            }
                        else{
                        Transaction transaction(rienfaire);
                        return transaction;}
                    }
                  else{ //fama  articles fil bourse lyowm a9al mil prix mt3h
                      int index = rand() % prixJournaliersDisponiblesaAcheter.size();
                      PrixJournalier pj= prixJournaliersDisponiblesaAcheter[index];
                      double prixAction= pj.getPrix();
                      string action =pj.getAction();
                      double quantite= floor(portefeuille.getSolde()/prixAction);
                      Transaction transaction(acheter,action,quantite);
                      Titre t(action, quantite);
                      trader.getPortefeuille().ajouterTitre(t);
                      trader.getPortefeuille().retirerMontant(prixAction*quantite);
                      return transaction;
                }
                }
        else if (type==vendre){ //vente
                              if(titresDeTraderDisponiblesDansLaBourseAujourdhui.empty()){  //mynjmch ybi3 les titres mt3ah mch mawjoudin
                                   do{
                                       TypeTransaction type = static_cast<TypeTransaction>(rand()%3);}while(type=vendre);
                                   if (type==acheter){
                                       if(prixJournaliersDisponiblesaAcheter.empty()){
                                           Transaction transaction(rienfaire);
                                           return transaction;
                                       }
                                       int index = rand() % prixJournaliersDisponiblesaAcheter.size();
                                       PrixJournalier pj= prixJournaliersDisponiblesaAcheter[index];
                                       double prixAction= pj.getPrix();
                                       string action =pj.getAction();
                                       double quantite= floor(portefeuille.getSolde()/prixAction);
                                       Transaction transaction(acheter,action,quantite);
                                       Titre t(action, quantite);
                                       trader.getPortefeuille().ajouterTitre(t);
                                       trader.getPortefeuille().retirerMontant(prixAction*quantite);
                                       return transaction;
                                       }
                                  else{
                                         Transaction transaction(rienfaire);
                                         return transaction;}
                              }
                            else{ //ynjm ybi3 les titres mt3ah  mawjoudin
                                  int index = rand() % titresDeTraderDisponiblesDansLaBourseAujourdhui.size();
                                  PrixJournalier prixJournalierAvendre=titresDeTraderDisponiblesDansLaBourseAujourdhui[index];
                                  for(Titre i: titresDeTrader){
                                         if (i.getAction()== prixJournalierAvendre.getAction()){
                                              double quantiteAvendre = 1.0 + static_cast<double>(rand()) / RAND_MAX * (i.getQt());
                                              break;}
                                              }
                                  string action =prixJournalierAvendre.getAction();
                                  double prixAction = prixJournalierAvendre.getPrix();
                                  Titre titreAvendre(action,quantiteAvendre);
                                  trader.getPortefeuille().retirerTitre(&titreAvendre);
                                  trader.getPortefeuille().deposerMontant(prixAction*quantiteAvendre);
                                  Transaction transaction(vendre,action,quantiteAvendre);
                                  return transaction;
                 }

              }
       else{
                Transaction transaction(rienfaire);
                return transaction;
                }
            }

}
}
void Simulation::executer (Bourse& bourse, Trader& trader, Date dateDebut, Date dateFin, double solde){
    bourse.setDateAujourdhui(dateDebut);
    int nbrTxParJour=0;
    while (bourse.getDateAujourdhui()<dateFin){
        do{
            Transaction transaction=trader.choisirTransaction(bourse,trader.getPortefeuille());
            nbrTxParJour++;
            if(transaction.getType()==rienfaire){
                     bourse.getDateAujourdhui().incrementerDate();
                     bourse.setDateAujourdhui(bourse.getDateAujourdhui());}
        }while(nbrTxParJour < 100);
        bourse.getDateAujourdhui().incrementerDate();
        bourse.setDateAujourdhui(bourse.getDateAujourdhui());
    }
    vector<Titre> titresDeTrader=trader.getPortefeuille().getTitres()
    for(Titre titre : titresDeTrader){
             vector<PrixJournalier> prixJournaliersDisponibles = bourse.getPrixJournaliersDisponiblesParDate(bourse.getDateAujourdhui());
             for (int i = prixJournaliersDisponibles.size() - 1; i >= 0; i--) {
                if (prixJournaliersDisponibles[i].getAction() == titre.getAction()) {
                       double prixAction = prixJournaliersDisponibles[i].getPrix();
                       double quantite =titre.getQt();
                       trader.getPortefeuille().retirerTitre(&titre);
                       trader.getPortefeuille().deposerMontant(prixAction*quantite);}
        }
    }

}
bool Test::testDate(Date d) {
    bool DateValide = true;
    if (d.annee < 0 || d.mois < 1 || d.mois > 12 || d.jour < 1) {
        DateValide = false;
    } else {
        int limiteJour = 31;
        if (d.mois == 2) {
            if (d.annee % 4 == 0) {
                limiteJour = 29;
            } else {
                limiteJour = 28;
            }
        } else if (d.mois == 4 || d.mois == 6 || d.mois == 9 || d.mois == 11) {
            limiteJour = 30;
        }
        DateValide = (d.jour >= 1 && d.jour <= limiteJour);
    }
    if(DateValide==false){
        cout<<"Erreur :Date invalide!"<<endl;
        return DateValide;
    }
    return DateValide ;
}
bool Test::testPrixJournaliers(PrixJournalier PJ){
    bool PJValide = true;
    if (testDate(PJ.getDate())){PJValide = false;}
    if (PJ.getPrix()<=0){PJValide = false;}
    if(PJValide==false){
        cout<<"Erreur :PrixJournaliers invalide!"<<endl;
        return PJValide ;
    }
    return PJValide;


}
bool
int main()

{
    srand (time(NULL));
    map<string, long> stats;
    stats["MON_COMPTEUR"]++;
    auto start = chrono::high_resolution_clock::now();
    Date d1;
    cin>> d1;
    cout<<d1;
    Date d2;
    cin>>d2;
    d1.incrementerDate();
    cout << d1 << endl;

    vector<PrixJournalier>historique=PersistancePrixJournaliers::lirePrixJournaliersDUnFichier("C:\\Users\\Zhome\\Documents\\prices_simple.csv");
   /* for(int i = 0; i < historique.size(); i++) {
        cout << historique[i] << endl;
    }*/  // afficher le vecteur historique
    BourseVector v(historique);

    Titre t1("act", 123);
    Titre t2("at", 12);
    Titre t3("ac", 13);
    vector<Titre> titres;
    titres.push_back(t1);
    titres.push_back(t1);
    titres.push_back(t1);
    Portefeuille p(titres, 133);
    TraderAleatoire trader("jack",p);
    auto stop = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    stats["TEMPS_GET_ACTIONS_DISPO_AUJ_�s"]+=duration.count();
    Simulation::executer(v,trader, d1, d2, 134411);
    for(auto it:stats){   cout<<it.first<<"\t"<<it.second<<endl; }
    return 0;
}
