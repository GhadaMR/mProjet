
#include <iostream>

#ifndef TRANSACTION_H
#define TRANSACTION_H

#include <string>
#include <vector>
using namespace std;




enum TypeTransaction {acheter, vendre, rienfaire};
class Transaction{
    private:
        TypeTransaction type;
        string nomAction;
        int quantite;
     public:
        Transaction(TypeTransaction t):type(t){};
        TypeTransaction getType(){return type;};
        Transaction(TypeTransaction t,string a,int q):type(t),nomAction(a),quantite(q){};
};
 #endif
