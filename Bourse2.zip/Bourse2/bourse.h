#ifndef BOURSE_H
#define BOURSE_H

#include <string>
#include <vector>

#include "portefeuille.h"
#include"date.h"
#include"prixjournaliers.h"

class Bourse{
 protected:
    Date dateAujourdhui;
 public:
    Date getDateAujourdhui() { return dateAujourdhui;}
    void setDateAujourdhui(Date date){dateAujourdhui=date;}
    virtual vector<PrixJournalier> getPrixJournaliersDisponiblesParAujourdhui()=0;
    virtual vector<string> getActionsDisponiblesParPrix(double prix)=0;
    virtual vector<string> getActionsDisponiblesParAujourdhui()=0;
    virtual vector<string> getActionsDisponiblesParDate(Date date)=0;

    virtual vector<PrixJournalier> getPrixJournaliersParAction(string action)=0;
    virtual vector<PrixJournalier> getPrixJournaliersParDate(Date date)=0;
    virtual vector<PrixJournalier> getPrixJournaliersParPrix(double prix)=0;
    virtual vector<PrixJournalier> getPrixJournaliersParPrixAujourdhui(double prix)=0;
    virtual ~Bourse(){};


};

class BourseVector: public Bourse
{
 private:
    vector<PrixJournalier> prixj;
 public:
    BourseVector( vector<PrixJournalier> historique) : prixj(historique) {};
    vector<PrixJournalier> getPrixjournaliers();
    vector<PrixJournalier> getPrixJournaliersDisponiblesParAujourdhui();
   vector<string>  getActionsDisponiblesParPrix(double prix);
   vector<string>  getActionsDisponiblesParAujourdhui();
   vector<string>  getActionsDisponiblesParDate(Date date);
   vector<PrixJournalier> getPrixJournaliersParAction(string action);
   vector<PrixJournalier> getPrixJournaliersParDate(Date date);
   vector<PrixJournalier> getPrixJournaliersParPrix(double prix);
    vector<PrixJournalier> getPrixJournaliersParPrixAujourdhui(double prix);

};
#endif
