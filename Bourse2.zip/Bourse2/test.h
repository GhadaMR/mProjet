#ifndef TEST_H
#define TEST_H


#include"date.h"
class Test{
public:
    bool testDate(Date date);
    bool testPrixJournaliers(PrixJournalier PJ);


};
#endif
