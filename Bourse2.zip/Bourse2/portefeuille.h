#ifndef PORTEFEUILLE_H
#define PORTEFEUILLE_H

#include <string>
#include <vector>
#include "bourse.h"
#include"titre.h"



class Portefeuille{
   private:

       vector<Titre> titres;
       double solde;
   public:

       Portefeuille(vector<Titre> t,double s):titres(t),solde(s){};
       double getSolde(){return solde;};
       vector<Titre> getTitres(){return titres;};
       void ajouterTitre (Titre titre);
       void retirerTitre(Titre* titre);
       void deposerMontant(double montant);
       void retirerMontant(double montant);
};
#endif
