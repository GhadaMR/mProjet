#include <iostream>

#ifndef TITRE_H
#define TITRE_H

#include <string>
#include <vector>
using namespace std;


class Titre{
    private:
      string action;
      double qt;
    public:
      Titre(string a, float q): action(a), qt(q){};
      string getAction()const {return action;};
      double getQt()const{return qt;};
      void setQt(double q){qt=q;};
};

#endif
