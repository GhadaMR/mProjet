#ifndef TRADER_H
#define TRADER_H

#include <string>
#include <vector>
#include "bourse.h"
#include "portefeuille.h"
#include"transaction.h"

class Trader {
protected:
    Portefeuille portefeuille;

public:
    virtual Transaction choisirTransaction( Bourse& bourse,  Portefeuille& portefeuille) = 0;
    Trader(Portefeuille p) : portefeuille(p) {};
    virtual ~Trader() {};
    std::string getNom() const;
    Portefeuille& getPortefeuille() { return portefeuille; }
};

class TraderAleatoire : public Trader {
public:
    Transaction choisirTransaction( Bourse& bourse,  Portefeuille& portefeuille);
    TraderAleatoire(Portefeuille p) : Trader(p) {};
};

#endif  // TRADER_H

