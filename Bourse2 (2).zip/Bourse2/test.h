#ifndef TEST_H
#define TEST_H


#include"date.h"
class Test{
public:
    Test(){};
    bool testDate(Date date);
    bool testPrixJournaliers(PrixJournalier PJ);



};
#endif
