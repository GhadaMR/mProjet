#include <iostream>
#include <string>
#include<vector>
#include<fstream>
#include <ctime>
#include <cmath>
#include <cstdlib>
#include <sstream>
#include<chrono>
#include<map>
#include <cassert>
#include "trader.h"
#include "bourse.h"
#include "portefeuille.h"
#include"date.h"
#include"test.h"
#include"prixjournaliers.h"
#include"simulation.h"
#include"titre.h"
#include"traderaleatoire.h"
#include"TraderaMoyenTerme.h"
using namespace std;

bool Date::operator==(const Date& d)const{
   return (jour==d.jour &&mois==d.mois && annee==d.annee);
   }
bool Date::operator < (const Date& d)const{
   return (d.annee>annee || (d.annee==annee && d.mois>mois) || (d.annee==annee && d.mois==mois && d.jour>jour));
}
void Date:: incrementerDate()
{
    int limiteJour = 31;
    if (mois == 2) {
        if ((annee % 4 == 0 && annee % 100 != 0 )|| annee % 400 == 0) {
            limiteJour = 29;
        } else {
            limiteJour = 28;
        }
    } else if (mois == 4 || mois == 6 || mois == 9 || mois == 11) {
        limiteJour = 30;
    }
    jour++;
    if (jour > limiteJour) {
        jour = 1;
        mois++;
    }
    if (mois > 12) {
        jour=1;
        mois = 1;
        annee++;
    }
}
Date::Date(int j,int m,int a):jour(j), mois(m), annee(a){}



class PersistancePrixJournaliers {
public:
    static vector<PrixJournalier> lirePrixJournaliersDUnFichier(string chemin) {
        vector<PrixJournalier> historique;
        ifstream f(chemin);
        int nbLignes = 0;
        string entete;
        if (f.is_open()) {
            getline(f, entete);
            while (!f.eof()) {
                PrixJournalier pj;
                f >> pj;
                historique.push_back(pj);
                nbLignes++;
            }
        }
        f.close();
        return historique;
    }
};
vector<PrixJournalier>BourseVector:: getPrixjournaliers(){
        vector<PrixJournalier> pjs;
        for(auto i:prixj){
            pjs.push_back(i);
        }
        return pjs;
    }
 vector<string>BourseVector::getActionsDisponiblesParPrix(double prix) const
        {
        vector<PrixJournalier> prj =getPrixJournaliersParPrix(prix);
        vector<string> actionsParPrix;
        for(auto i : prj)
        {
                actionsParPrix.push_back(i.getAction());
        }
        return actionsParPrix;

}

    vector<string> BourseVector::getActionsDisponiblesParAujourdhui() const
    {
        vector<PrixJournalier> prjr=getPrixJournaliersDisponiblesParAujourdhui();
        vector<string> actionsAujourdhui;
        for(auto i : prjr){
                actionsAujourdhui.push_back(i.getAction());
                  }

        return actionsAujourdhui;
    }
    vector<string>BourseVector:: getActionsDisponiblesParDate(Date date) const
   {
        vector<string> actionsDisponibles;
        for (const auto& prix : prixj)
        {
            if (prix.getDate() == date && date < dateAujourdhui)
            {
                actionsDisponibles.push_back(prix.getAction());
            }
        }
        return actionsDisponibles;
    }
vector<PrixJournalier> BourseVector::getPrixJournaliersParDate(Date date) const
{
        vector<PrixJournalier> prixJournaliers;
        for (const auto& i : prixj)
        {
            if (i.getDate() == date && date< dateAujourdhui )
            {
                prixJournaliers.push_back(i);
            }
        }
        return prixJournaliers;
    }

    vector<PrixJournalier>BourseVector:: getPrixJournaliersParAction(string action)const {
        vector<PrixJournalier> prixJournaliers;
        for (const auto& prix : prixj)
        {
            if (prix.getDate() < dateAujourdhui &&prix.getAction() == action)
            {
                prixJournaliers.push_back(prix);
            }
        }
        return prixJournaliers;
    }
  PrixJournalier BourseVector:: getPrixJournalierParActionAujourdhui(string action)const{
        for (const auto& prix : prixj)
        {
            if (prix.getDate() == dateAujourdhui && prix.getAction() == action)
            {
                return prix;
            }
        }
         return PrixJournalier();
    }
   vector<PrixJournalier> BourseVector:: getPrixJournaliersParPrix(double prix)const{
        vector<PrixJournalier> prix_journaliers;
        int i=0;
        if(!prixj.empty()){
           while (prixj[i].getDate() < dateAujourdhui && prixj.size()>i)
          {
              if (prixj[i].getPrix() <=prix)
              {
                prix_journaliers.push_back(prixj[i]);
              }
              i++;
          }
        }
        return prix_journaliers;
   }
    vector<PrixJournalier> BourseVector:: getPrixJournaliersParPrixAujourdhui(double prix)const{
        vector<PrixJournalier> prixJournaliers;
        for (const auto& i : prixj)
        {
            if (i.getPrix() < prix && i.getDate()== dateAujourdhui )
            {
                prixJournaliers.push_back(i);
            }
        }
        return prixJournaliers;
    }
vector<PrixJournalier> BourseVector::getPrixJournaliersDisponiblesParAujourdhui()const{
        vector<PrixJournalier> prix_journaliers;
        int i=0;
        if(!prixj.empty()){
         while ( prixj.size()>i)
        {
            if (prixj[i].getDate() == dateAujourdhui)
            {
                prix_journaliers.push_back(prixj[i]);
            }
             i++;
        }
    }
          return prix_journaliers;
    }



vector<PrixJournalier>  BourseMap::getPrixJournaliersParPrix(double prix)const
{
    vector<PrixJournalier> prixJournaliers;
    for ( auto pair : bourseMap)
    {
        if (pair.second.getPrix() <= prix&& pair.first < dateAujourdhui )
        {
            prixJournaliers.push_back(pair.second);
        }
    }
    return prixJournaliers;
}
vector<PrixJournalier>  BourseMap::getPrixJournaliersDisponiblesParAujourdhui() const
{

    vector<PrixJournalier> prixJournaliers;
    auto it = bourseMap.begin();
    while (it != bourseMap.end())
    {
        if (it->first == dateAujourdhui)
        {
            prixJournaliers.push_back(it->second);
        }
        ++it;
    }
    return prixJournaliers;
}
vector<PrixJournalier> BourseMap::getPrixJournaliersParDate(Date date)const
{

    vector<PrixJournalier> prixJournaliers;
    auto it = bourseMap.begin();
  if( date < dateAujourdhui){
    while (it != bourseMap.end())
    {
        if (it->first == date)
        {
            prixJournaliers.push_back(it->second);
        }
        ++it;
    }
  }
    return prixJournaliers;
}
vector<PrixJournalier> BourseMap::getPrixJournaliersParAction(string action)const
{
    vector<PrixJournalier> prixJournaliers;
    auto it = bourseMap.begin();
    while (it != bourseMap.end())
    {
        if (it->second.getAction() == action && it->first < dateAujourdhui)
        {
            prixJournaliers.push_back(it->second);
        }
        ++it;
    }
    return prixJournaliers;
}
vector<PrixJournalier>  BourseMap::getPrixJournaliersParPrixAujourdhui(double prix)const
{

   vector<PrixJournalier> prixJournaliers;
    auto it = bourseMap.begin();
    while (it != bourseMap.end())
    {
        if (it->second.getPrix() <= prix&& it->first ==dateAujourdhui)
        {
            prixJournaliers.push_back(it->second);
        }
        ++it;
    }
    return prixJournaliers;
}
vector<string> BourseMap:: getActionsDisponiblesParPrix(double prix)const
        {
        vector<PrixJournalier>prj=getPrixJournaliersParPrix(prix);
        vector<string> actionsParPrix;
        for(auto i : prj)
        {
                actionsParPrix.push_back(i.getAction());

        }
        return actionsParPrix;

}
vector<string> BourseMap:: getActionsDisponiblesParAujourdhui()const
    {
       vector<PrixJournalier> prjr=getPrixJournaliersDisponiblesParAujourdhui();
         vector<string> actionsAujourdhui;
        for(auto i : prjr){
                actionsAujourdhui.push_back(i.getAction());
                  }
        return actionsAujourdhui;
    }
vector<string> BourseMap::getActionsDisponiblesParDate(Date date)const
    {
         vector<PrixJournalier> prj =getPrixJournaliersParDate(date);
        vector<string> actions;


        for (auto i : prj)
        {
                actions.push_back(i.getAction());
            }
        return actions;

}
 PrixJournalier BourseMap:: getPrixJournalierParActionAujourdhui(string action)const{
        for (const auto& prix : prixj)
        {
            if (prix.getDate() == dateAujourdhui && prix.getAction() == action)
            {
                return prix;
            }
        }
         return PrixJournalier();
    }
void Portefeuille:: ajouterTitre (Titre titre){
        bool found = false;
        for (auto &t : titres) {
            if (t.getAction() == titre.getAction()) {
                t.setQt(t.getQt() + titre.getQt());
                found = true;
                break;
            }
        }
        if (!found) {
            titres.push_back(titre);
        }

}
bool Portefeuille:: retirerTitre(Titre* titre) {
        for (auto it = titres.begin(); it != titres.end(); ++it) {
            if (it->getAction() == titre->getAction() && it->getQt() >= titre->getQt()) {
                if (it->getQt() == titre->getQt()) {
                    titres.erase(it);
                } else {
                    it->setQt(it->getQt() - titre->getQt());
                }
                return true;
            }
        }
        return false;
    }
void Portefeuille:: deposerMontant(double montant){solde+=montant;}
void Portefeuille:: retirerMontant(double montant){solde-=montant;}


map<string, long> Simulation::executer(Bourse& bourse, Trader& trader, Date dateDebut, Date dateFin, double solde){
        map<string, long> stats;
        long compteurVente=0;
        long compteurAchat=0;
        vector<Titre> Titres;
        Portefeuille portefeuille(Titres,solde);
        if (dateDebut <bourse.getDateAujourdhui()){
            bourse.setDateAujourdhui(dateDebut);
        }
        int nbrTxParJour=0;

         cout<<"Solde initiale"<<solde<<endl;
         cout<<"Taille de titres initiale:"<<portefeuille.getTitres().size()<<endl;
        // Mesurer le temps d'ex�cution d'une partie du code
        auto start = chrono::high_resolution_clock::now();
        while (bourse.getDateAujourdhui() < dateFin){
             cout<<bourse.getDateAujourdhui()<<endl;

            do{

                Transaction transaction = trader.choisirTransaction(bourse, portefeuille);

                nbrTxParJour++;
                cout<<"nb"<<nbrTxParJour<<endl;
                if (transaction.getType() == RIEN_FAIRE){
                    cout<<"RIEN_FAIRE"<<endl;
                    bourse.getDateAujourdhui().incrementerDate();
                } else if (transaction.getType() == ACHETER){
                    if(bourse.getPrixJournalierParActionAujourdhui(transaction.getNomAction()).getAction()!=" "){
                    cout<<"ACHETER"<<endl;
                    double prixAction = bourse.getPrixJournalierParActionAujourdhui(transaction.getNomAction()).getPrix();
                    cout<<"action:" <<transaction.getNomAction()<<"|"<<"prixAction:"<<prixAction<<endl;
                    int quantite = transaction.getQuantite();
                    cout<<"QT:"<<quantite<<endl;
                    double montant = prixAction * quantite;
                    cout<<"� montant:"<<montant<<endl;
                    Titre titre(transaction.getNomAction(), quantite);
                    portefeuille.retirerMontant(montant);
                    cout<<"Current Solde:"<< portefeuille.getSolde()<<endl;
                    portefeuille.ajouterTitre(titre);
                    compteurAchat++;
                    cout<<"Taille du titres :"<<portefeuille.getTitres().size()<<endl;
                    for(auto i: portefeuille.getTitres()){
                        cout<<i.getAction()<<i.getQt()<<endl;

                    }
                    }
                } else if (transaction.getType() == VENDRE){
                    if(bourse.getPrixJournalierParActionAujourdhui(transaction.getNomAction()).getAction()!=" "){
                    cout<<"VENDRE"<<endl;
                    double prixAction = bourse.getPrixJournalierParActionAujourdhui(transaction.getNomAction()).getPrix();
                    cout<<"action:" <<transaction.getNomAction()<<"prix:"<<prixAction<<endl;
                    int quantite = transaction.getQuantite();
                    cout<<"QT:"<<quantite<<endl;
                    Titre titre(transaction.getNomAction(), quantite);
                    cout<<"Taille du titres i :"<<portefeuille.getTitres().size()<<endl;
                    if(portefeuille.retirerTitre(&titre)){
                    cout<<"Taille du titres i+1:"<<portefeuille.getTitres().size()<<endl;
                    portefeuille.deposerMontant(prixAction*quantite);
                    compteurVente++;
                    cout<<"Current Solde:"<< portefeuille.getSolde()<<endl;}
                }
                }
            } while (nbrTxParJour<100);
            cout<<(nbrTxParJour<2)<<endl;
            nbrTxParJour = 0;
            bourse.getDateAujourdhui().incrementerDate();
            Date d1= bourse.getDateAujourdhui();
            d1.incrementerDate();

            bourse.setDateAujourdhui(d1);

        }


        for (Titre& titre : portefeuille.getTitres()){
            for (int i = bourse.getPrixJournaliersParAction(titre.getAction()).size() - 1; i >= 0; i--){
                if (bourse.getPrixJournaliersParAction(titre.getAction())[i].getDate() < dateFin){
                    double prixAction = bourse.getPrixJournaliersParAction(titre.getAction())[i].getPrix();
                    int quantite = titre.getQt();
                    Titre titreCopie(titre.getAction(), quantite);
                     cout<<"Taille du titres i:"<<portefeuille.getTitres().size()<<endl;
                    portefeuille.retirerTitre(&titreCopie);
                     cout<<"Taille du titres i+1:"<<portefeuille.getTitres().size()<<endl;
                    portefeuille.deposerMontant(prixAction * quantite);

                    cout<<"Current Solde:"<< portefeuille.getSolde()<<endl;
                    break;
                }
            }
        }
       auto stop = chrono::high_resolution_clock::now();
        auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);

        // Ajouter la dur�e � la statistique correspondante
        stats.insert(make_pair("tempsExecutionSimulationPar�s", duration.count()));
        stats.insert(make_pair("soldeFinaleDeTrader", portefeuille.getSolde()));
        stats.insert(make_pair("nombreDeVente", compteurVente));
        stats.insert(make_pair("nombreDeAchat", compteurAchat));

    return stats;
}



bool Test :: testDate(Date d){
    bool DateValide = true;
    if (d.annee < 0 || d.mois < 1 || d.mois > 12 || d.jour < 1) {
        DateValide = false;
    } else {
        int limiteJour = 31;
        if (d.mois == 2) {
            if ((d.annee % 4 == 0 && d.annee % 100 != 0 )|| d.annee % 400 == 0) {
                limiteJour = 29;
            } else {
                limiteJour = 28;
            }
        } else if (d.mois == 4 || d.mois == 6 || d.mois == 9 || d.mois == 11) {
            limiteJour = 30;
        }
        DateValide = (d.jour >= 1 && d.jour <= limiteJour);
    }
    if(DateValide==false){
        return DateValide;
    }
    return DateValide ;
}
bool Test :: testPrixJournaliers(PrixJournalier PJ){
    bool PJValide = true;
    if (testDate(PJ.getDate())){PJValide = false;}
    if (PJ.getPrix()<=0){PJValide = false;}
    return PJValide ;
}

vector<PrixJournalier> BourseMultiset::getPrixJournaliersDisponiblesParAujourdhui()const{
        vector<PrixJournalier> prixJournaliers;
        for (const auto& i : prixj)
        {
            if (i.getDate() == dateAujourdhui)
            {
                prixJournaliers.push_back(i);
            }
        }
        return prixJournaliers;
    }
vector<string> BourseMultiset::getActionsDisponiblesParAujourdhui()const{
        vector<string> actionsDisponibles;
        for (const auto& i : prixj)
        {
            if (i.getDate() == dateAujourdhui)
            {
                actionsDisponibles.push_back(i.getAction());
            }
        }
        return actionsDisponibles;
    }
vector<string> BourseMultiset::getActionsDisponiblesParDate(Date date)const{
        vector<string> actionsDisponibles;
        for (const auto& prix : prixj)
        {
            if (prix.getDate() == date && date< dateAujourdhui)
            {
                actionsDisponibles.push_back(prix.getAction());
            }
        }
        return actionsDisponibles;
    }
vector<string> BourseMultiset::getActionsDisponiblesParPrix(double prix)const {
        vector<string> actionsDisponibles;
        for (const auto& i : prixj)
        {
            if (i.getDate()< dateAujourdhui && i.getPrix()== prix)
            {
                actionsDisponibles.push_back(i.getAction());
            }
        }
        return actionsDisponibles;
    }

vector<PrixJournalier> BourseMultiset::getPrixJournaliersParAction(string action)const{
        vector<PrixJournalier> prixJournaliers;
        for (const auto& i : prixj)
        {
            if (i.getDate()< dateAujourdhui && i.getAction() == action)
            {
                prixJournaliers.push_back(i);
            }
        }
        return prixJournaliers;
    }
PrixJournalier BourseMultiset::getPrixJournalierParActionAujourdhui(string action)const{
        for (const auto& prix : prixj)
        {
            if (prix.getDate() == dateAujourdhui && prix.getAction() == action)
            {
                return prix;
            }
        }
         return PrixJournalier();
    }
vector<PrixJournalier> BourseMultiset::getPrixJournaliersParDate(Date date)const{
        vector<PrixJournalier> prixJournaliers;
        for (const auto& i : prixj)
        {
            if (i.getDate() == date && date< dateAujourdhui )
            {
                prixJournaliers.push_back(i);
            }
        }
        return prixJournaliers;
    }
vector<PrixJournalier> BourseMultiset::BourseMultiset::getPrixJournaliersParPrix(double prix)const{
        vector<PrixJournalier> prixJournaliers;
        for (const auto& i : prixj)
        {
            if (i.getPrix() < prix && i.getDate()< dateAujourdhui )
            {
                prixJournaliers.push_back(i);
            }
        }
        return prixJournaliers;
    }
vector<PrixJournalier> BourseMultiset::getPrixJournaliersParPrixAujourdhui(double prix)const{
        vector<PrixJournalier> prixJournaliers;
        for (const auto& i : prixj)
        {
            if (i.getPrix() < prix && i.getDate()== dateAujourdhui )
            {
                prixJournaliers.push_back(i);
            }
        }
        return prixJournaliers;
    }

int main()
{
    srand(time(NULL));
    map<string, long> stats;
    stats["MON_COMPTEUR"]++;

    Date d1,d2;
    d1=Date(4,1,2010);
    d2=Date(5,1,2010);

    vector<PrixJournalier> historique = PersistancePrixJournaliers::lirePrixJournaliersDUnFichier("C:\\Users\\hp\\Desktop\\enit\\S2\\MP\\prices_simple.txt");

    // BourseVector v (d2,historique);
    //BourseMultiset v(d2,historique);
    //BourseMap v(d2,historique);

    //vector<PrixJournalier> pjs =v.getPrixjournaliers();
    // multiset<PrixJournalier> pjs =v.getPrixjournaliers();
    // multimap<Date, PrixJournalier> pjs =v.getPrixjournaliers();

    //vector<PrixJournalier> pjs= v.getPrixJournaliersDisponiblesParAujourdhui();
    //vector<string> pjs=v.getActionsDisponiblesParAujourdhui();
    //vector<string> pjs=v.getActionsDisponiblesParDate(d1);
    //vector<string> pjs=v.getActionsDisponiblesParPrix(20);
    //vector<PrixJournalier> pjs=v.getPrixJournaliersParAction("IPG");
    //cout<<v.getPrixJournalierParActionAujourdhui("DUK")<<endl;
    //vector<PrixJournalier> pjs=v.getPrixJournaliersParDate(d1);
    //vector<PrixJournalier> pjs=v.getPrixJournaliersParPrix(28.67);
    //vector<PrixJournalier> pjs=v.getPrixJournaliersParPrixAujourdhui(20);

    //for(int i = 0; i < pjs.size(); i++) {
    //cout << pjs[i] << endl;}

    //TraderaMoyenTerme trader;
    TraderAleatoire trader;

    auto start = chrono::high_resolution_clock::now();
    auto prixAujourdhui = v.getPrixJournaliersParDate(d1);
    auto stop = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);

    Simulation sim;
    stats = sim.executer(v, trader, d1, d2,123569);
    stats["TEMPS_GET_ACTIONS_DISPO_AUJ_�s"]+=duration.count();

    for (const auto& it   : stats) {
        cout << it.first << "\t" << it.second << endl;
    }
    int nb=0;

  /*for (auto i: prixAujourdhui){

    cout<<i<<endl;
    nb++;
  }
  cout<<nb;*/

    return 0;
    }


