
#ifndef TRADERAMOYENTERME_H
#define TRADERAMOYENTERME_H

#include <string>
#include <vector>
#include "bourse.h"
#include "portefeuille.h"
#include"transaction.h"
#include"trader.h"


class TraderaMoyenTerme: public Trader{
  public:
      TraderaMoyenTerme():Trader(){};

       Transaction choisirTransaction(const Bourse& bourse, const Portefeuille &portefeuille){


      vector<PrixJournalier> prixJournaliersDisponiblesDansLaBourseAujourdhui = bourse.getPrixJournaliersDisponiblesParAujourdhui();
      vector<Titre> titresDeTrader = portefeuille.getTitres();
      vector<PrixJournalier> titresDeTraderDisponiblesDansLaBourseAujourdhui;
      vector<PrixJournalier> prixJournaliersDisponiblesaAcheter = bourse.getPrixJournaliersParPrixAujourdhui(portefeuille.getSolde());
      vector<string>actionsTrader;
      for (auto i : prixJournaliersDisponiblesDansLaBourseAujourdhui) {
        for (auto titre : titresDeTrader) {
            actionsTrader.push_back(titre.getAction());
            if (i.getAction() == titre.getAction()) {

                titresDeTraderDisponiblesDansLaBourseAujourdhui.push_back(i);
            }
        }
    }

     if (titresDeTrader.empty()) {
        if (prixJournaliersDisponiblesaAcheter.empty()) {
            Transaction transaction(RIEN_FAIRE);
            return transaction;
        }

        else {
        double prixAction;
        for (const string& action : actionsTrader) {
        // Obtenez les prix journaliers pour l'action en cours
        vector<PrixJournalier> prixJournaliers = bourse.getPrixJournaliersParAction(action);

        // V�rifiez si les prix journaliers sont suffisamment nombreux pour prendre une d�cision
        if (prixJournaliers.size() >= 2) {
            // Obtenez le dernier prix journalier
            PrixJournalier dernierPrix = prixJournaliers.back();

            // Obtenez le prix journalier pr�c�dent
            PrixJournalier prixPrecedent = prixJournaliers[prixJournaliers.size() - 2];

            // V�rifiez si le prix a augment� entre le prix pr�c�dent et le dernier prix
            if (dernierPrix.getPrix() > prixPrecedent.getPrix()) {
                // V�rifiez si l'action est d�j� d�tenue dans le portefeuille
                for(auto i:portefeuille.getTitres()){
                     if (i.getAction()!=action) {
                    // Achetez l'action si elle n'est pas d�j� d�tenue
                    int quantite = floor(portefeuille.getSolde() / prixAction);
                    Transaction transaction(ACHETER, action, quantite);
                    return transaction;
                    }
                    }
                }

        }
    }}
     }
 /* else {
        if (portefeuille.getSolde() == 0) {
            if (titresDeTraderDisponiblesDansLaBourseAujourdhui.empty()) {
                Transaction transaction(RIEN_FAIRE);
                return transaction;
            }
        }

    // Parcourez les actions d�tenues pour prendre une d�cision de vente
     for (const string& action : actionsTrader) {
        // Obtenez le prix journalier actuel de l'action
        PrixJournalier prixActuel = bourse.getPrixJournalierParActionAujourdhui(action);

        // V�rifiez si le prix est sup�rieur au prix d'achat de l'action
        if (prixActuel.getPrix() > portefeuille.getPrixAchat(action)) {
            // Vendez l'action si le prix est sup�rieur au prix d'achat
            int quantiteAvendre=
            Transaction transaction(VENDRE, action, quantiteAvendre);// Vente de la quantit� totale d�tenue de l'action
            return transaction;
        }
    }4

    }
        else{
                    Transaction transaction(RIEN_FAIRE);
                    return transaction;
                }
      };


*/
};
};

#endif  // TRADER_H


